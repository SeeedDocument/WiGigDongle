1. Run Setup_1_0_3_26.msi
2. Plug-in device
3. Run InstallINF_x64.exe if 64bit system or run InstallINF_x32.exe if 32bit system