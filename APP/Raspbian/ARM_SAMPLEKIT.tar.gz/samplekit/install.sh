#!/bin/bash

echo "Install USB setup file"
sudo cp ./88-cyusb.rules /etc/udev/rules.d/

echo "Done"
