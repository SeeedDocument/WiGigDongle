
#include <iostream>
#include "include/mrloopbf_release.h"

int main(int argc, const char * argv[]) {
    // insert code here...
    if(ML_Init()){
        ML_Close();
        std::cout << "Hello, World!\n";
    }else{
        std::cout << "WTF!\n";

    }
    return 0;
}
