package com.mrloop.speedtesttool;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.mrloop.mrlooplib.MrloopFunction;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {

    final String DEBUG = "SpeedTest";
    MrloopFunction dFunction = new MrloopFunction();
    Button btn_tx, btn_rx;
    TextView tv_bitrate, tv_errorpkt;
    ProgressBar bitrate_bar;
    RadioButton rb_default, rb_pcp, rb_sta;
    RadioGroup radioGroup;

    boolean show_bitrate = false, txindex = false, rxindex = false, index = false;

    long bitrate = 0;
    int mbps = 0;

    Timer timer;

    SpeedRx sr;
    SpeedTx st;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_bitrate = (TextView) findViewById(R.id.tv_bitrate);
        tv_errorpkt = (TextView) findViewById(R.id.tv_errorpkt);
        btn_tx = (Button) findViewById(R.id.btn_tx);
        btn_rx = (Button) findViewById(R.id.btn_rx);

        radioGroup = (RadioGroup) findViewById(R.id.rbg);
        //rb_default = (RadioButton) findViewById(R.id.rb_default);
        rb_pcp = (RadioButton) findViewById(R.id.rb_pcp);
        rb_sta = (RadioButton) findViewById(R.id.rb_sta);

        bitrate_bar = (ProgressBar) findViewById(R.id.progressBar);
        bitrate_bar.setMax(1000);
        bitrate_bar.setProgress(0);

        UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        try {
            dFunction.getDevices(usbManager);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (dFunction.DeviceConnection != null) {

            Toast.makeText(this, dFunction.ML_GetDescriptors(), Toast.LENGTH_SHORT).show();

            btn_tx.setOnClickListener(btntx);
            btn_rx.setOnClickListener(btnrx);
            radioGroup.setOnCheckedChangeListener(RFmode);

            timer = new Timer();
            timer.schedule(task, 0, 1000);

        } else {
            btn_tx.setVisibility(View.INVISIBLE);
            btn_rx.setVisibility(View.INVISIBLE);
            this.finish();
        }
    }

    TimerTask task = new TimerTask() {
        @Override
        public void run() {
            mbps = (int) ((bitrate * 8) / (1024 * 1024));
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tv_bitrate.setText(mbps + " Mbps");
                    bitrate_bar.setProgress(mbps);
                    bitrate = 0;

                    //tv_errorpkt.setText("Error: " + j.JniGetError());
                    //Log.e(DEBUG, "Now Error num: "+ j.JniGetError());
                }
            });
        }
    };


    private Button.OnClickListener btntx = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (!txindex) {
                txindex = true;
                st = new SpeedTx();
                st.start();

                btn_rx.setVisibility(View.INVISIBLE);
                btn_tx.setText("Stop");

            } else {
                txindex = false;
                index = false;
                btn_rx.setVisibility(View.VISIBLE);
                btn_tx.setText("Tx");
            }
        }
    };

    private Button.OnClickListener btnrx = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (!rxindex) {
                rxindex = true;
                index = true;
                sr = new SpeedRx();
                sr.start();
                btn_tx.setVisibility(View.INVISIBLE);
                btn_rx.setText("Stop");

            } else {
                rxindex = false;

                btn_tx.setVisibility(View.VISIBLE);
                btn_rx.setText("Rx");
            }
        }
    };

    private RadioGroup.OnCheckedChangeListener RFmode = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            switch (checkedId) {
                case R.id.rb_pcp:
                    dFunction.ML_SetMode((byte) 1);
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    dFunction.ML_SetSpeed((byte)6);
                    break;
                case R.id.rb_sta:
                    dFunction.ML_SetMode((byte) 2);
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    dFunction.ML_SetSpeed((byte)6);
                    break;
                default:
                    break;
            }
        }
    };

    private class SpeedTx extends Thread {

        byte[] buf = new byte[4096 * 4];

        @Override
        public void run() {

            bitrate = 0;

            while (txindex) {
                if (dFunction.ML_Transfer(buf) == 1) {
                    bitrate += 4096 * 4;
                }
            }
        }
    }

    private class SpeedRx extends Thread {

        byte[] buf = new byte[4096];

        @Override
        public void run() {

            bitrate = 0;

            //j.JniInit();
            while (rxindex) {
                if (dFunction.ML_Receive(buf, 500) == 1) {
                    bitrate += 4096;
                    //j.JniPushData(buf);
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (timer != null)
            timer.cancel();

        if (st != null) {
            if (st.isAlive()) {
                txindex = false;
                st.interrupt();
            }
        }

        if (sr != null) {
            if (sr.isAlive()) {
                rxindex = false;
                sr.interrupt();
            }
        }

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
        } else {
        }
    }
}
